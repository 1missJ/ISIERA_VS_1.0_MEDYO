<?php
function makeImageTransparent($originalPath) {
    $hash = md5($originalPath);
    $outputDir = 'uploads/transparent_signatures/';
    $outputFile = $outputDir . $hash . '.png';

    if (!file_exists($outputFile)) {
        if (!is_dir($outputDir)) mkdir($outputDir, 0755, true);

        $imgInfo = getimagesize($originalPath);
        if (!$imgInfo) return '';

        $mime = $imgInfo['mime'];
        switch ($mime) {
            case 'image/jpeg':
                $img = imagecreatefromjpeg($originalPath);
                break;
            case 'image/png':
                $img = imagecreatefrompng($originalPath);
                break;
            default:
                return '';
        }

        if ($img) {
            $width = imagesx($img);
            $height = imagesy($img);
            imagealphablending($img, false);
            imagesavealpha($img, true);

            $transparent = imagecolorallocatealpha($img, 255, 255, 255, 127);

            for ($x = 0; $x < $width; $x++) {
                for ($y = 0; $y < $height; $y++) {
                    $rgb = imagecolorat($img, $x, $y);
                    $colors = imagecolorsforindex($img, $rgb);
                    if ($colors['red'] > 240 && $colors['green'] > 240 && $colors['blue'] > 240) {
                        imagesetpixel($img, $x, $y, $transparent);
                    }
                }
            }

            imagepng($img, $outputFile);
            imagedestroy($img);
        }
    }

    return $outputFile;
}
?>
