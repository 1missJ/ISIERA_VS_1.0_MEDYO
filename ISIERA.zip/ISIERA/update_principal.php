<?php
include('db_connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $principalName = trim($_POST['principal_name']);

    if (isset($_FILES['principal_signature']) && $_FILES['principal_signature']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['principal_signature']['tmp_name'];
        $fileName = $_FILES['principal_signature']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // Only allow PNG and JPG
        $allowedExtensions = ['png', 'jpg', 'jpeg'];
        if (!in_array($fileExtension, $allowedExtensions)) {
            die("Invalid file type. Only PNG and JPG are allowed.");
        }

        // Generate custom filename
        $uniqueID = uniqid();
        $newFileName = $uniqueID . '_principal_signature.' . $fileExtension;
        $uploadDir = 'uploads/';
        $dest_path = $uploadDir . $newFileName;

        // Move uploaded file
        if (move_uploaded_file($fileTmpPath, $dest_path)) {
            // Update or insert principal data
            $check = $conn->query("SELECT COUNT(*) as total FROM principal")->fetch_assoc()['total'];

            if ($check > 0) {
                $stmt = $conn->prepare("UPDATE principal SET principal_name = ?, principal_signature = ?");
                $stmt->bind_param("ss", $principalName, $dest_path);
                $stmt->execute();
            } else {
                $stmt = $conn->prepare("INSERT INTO principal (principal_name, principal_signature) VALUES (?, ?)");
                $stmt->bind_param("ss", $principalName, $dest_path);
                $stmt->execute();
            }

            header("Location: dashboard.php");
            exit();
        } else {
            echo "Error uploading signature.";
        }
    } else {
        echo "No file uploaded or an error occurred.";
    }
} else {
    echo "Invalid request method.";
}
?>
